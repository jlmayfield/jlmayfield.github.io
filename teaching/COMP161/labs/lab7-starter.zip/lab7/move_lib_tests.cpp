/*
 Logan Mayfield
*/

#include <gtest/gtest.h>
#include <sstream>
#include <string>
#include "move_lib.h"

/**
   Lab TODO
   -  Write tests for all the procedures stubbed in lab.

 */


namespace {

  TEST(dispSt,all){
    std::string expected{""};
    std::ostringstream actual{""};

    expected = std::string("|X--------------------|\n");
    expected += std::string("wrapped: 0\n");
    movegame::ui::displayState(actual,0,0);

    EXPECT_EQ(expected,actual.str());

    actual.str("");
    actual.clear();
    expected.clear();

    expected = std::string("|-----X---------------|\n");
    expected += std::string("wrapped: 4\n");
    movegame::ui::displayState(actual,5,4);
    EXPECT_EQ(expected,actual.str());

    actual.str("");
    actual.clear();
    expected.clear();

    expected = std::string("|--------------------X|\n");
    expected += std::string("wrapped: 2\n");
    movegame::ui::displayState(actual,20,2);
    EXPECT_EQ(expected,actual.str());

    actual.str("");
    actual.clear();
    expected.clear();

  }

  TEST(getmv,all){
    std::istringstream in{""};
    int mv{0};

    in.clear();
    in.str("5");
    EXPECT_EQ(0,mv);
    movegame::ui::getMove(in,mv);
    EXPECT_EQ(5,mv);

  }

  TEST(getmvprompt,all){
    std::istringstream in{""};
    std::ostringstream out{""};
    int mv{0};
    std::string expected{""};

    in.str("5");
    expected = "move? ";
    movegame::ui::getMoveWithPrompt(out,in,mv);
    EXPECT_EQ(5,mv); // the input effect
    EXPECT_EQ(expected,out.str()); // the output effect

  }

  TEST(udtSt,all){

    int loc{0};
    int wrap{0};

    movegame::model::updateState(loc,wrap,3);
    EXPECT_EQ(3,loc);
    EXPECT_EQ(0,wrap);

    loc = 0;
    wrap = 0;

    movegame::model::updateState(loc,wrap,-3);
    EXPECT_EQ(18,loc);
    EXPECT_EQ(1,wrap);

    loc = 0;
    wrap = 0;

    movegame::model::updateState(loc,wrap,25);
    EXPECT_EQ(4,loc);
    EXPECT_EQ(1,wrap);

    loc = 0;
    wrap = 0;

    movegame::model::updateState(loc,wrap,50);
    EXPECT_EQ(8,loc);
    EXPECT_EQ(2,wrap);

    loc = 0;
    wrap = 0;
    movegame::model::updateState(loc,wrap,-50);
    EXPECT_EQ(13,loc);
    EXPECT_EQ(2,wrap);
  }

  TEST(movePrompt,all){
    std::string expected{"move? "};
    std::ostringstream actual{""};

    movegame::ui::movePrompt(actual);
    EXPECT_EQ(expected,actual.str());
  }

} // end ::
