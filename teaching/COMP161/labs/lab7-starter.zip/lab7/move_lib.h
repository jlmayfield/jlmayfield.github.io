/**
  Logan Mayfield
*/

#ifndef _MOVE_LIB_H
#define _MOVE_LIB_H

#include <iostream>

namespace movegame{

  //  User Interface Procedures
  namespace ui{
		
    /**
     * Write the board and number of wraps to the stream out
     * @param out the stream where the state visualization is written
     * @param loc the location of the player
     * @param wrap the number of times wrapped
     * @return none
     * @pre 0<=loc<21 , 0<=wrap
     * @post representation of the game state is written to the
     *   stream out
     */
    void displayState(std::ostream& out,
		      int loc, int wrap);

    /**
     * Get the number of spaces to move from the player
     * @param in the stream where user input can be found
     * @param move the variable where the user's move is stored
     * @return none
     * @pre none
     * @post the user's move (int number of steps) is read from
     *    in
     */						  
    void getMove(std::istream& in, int& move);		

    
    /**
     * Prompt the user for the number of spaces to move and get that 
     *  number from the player 
     * @param out the stream where the prompt is written
     * @param in the stream where user input can be found
     * @param move the variable where the user's move is stored
     * @return none
     * @pre none
     * @post a prompt is written to out and the user's move 
     *  (int number of steps) is read from in
     */						  
    void getMoveWithPrompt(std::ostream& out, std::istream& in, int& move);		

    /**
     * Write the board visualization to the stream out
     * @param out the stream where the board state is written
     * @param loc the location of the player on the board
     * @return a reference to out to enable chainning output
     * @pre 0 <= loc < 21
     * @post a visualization of the board is written to out     
     */
    // TODO Declare displayLocOnBoard 


    /**
     * // TODO Document displayWrap
     */
    std::ostream& displayWrap(std::ostream& out, int wrap);

    /**
     * Display the getMove prompt on the stream out
     * @param out the stream where the prompt is written
     * @return none
     * @pre none
     * @post prompt written to out
     */
    void movePrompt(std::ostream& out);
    
  } // end ui


  // Core State/Model Handling Procedure
  namespace model{
	
    /**
     * Modify the location state and wrapped score based on the 
     *   most recent move.
     * @param curr_loc current player location
     * @param num_wrap number of times player has wrapped
     * @return none
     * @pre 0<= cur_loc < 21. 0= num_wrap. 
     * @post curr_loc moved move spaces and num_wrap is 
     *   incremented accordingly 
     */
    void updateState(int& cur_loc, int& num_wrap, int move);

    /**
     * TODO Document boardString function
     */
    std::string boardString(int loc);

    /**
     * Compute the UI string for displaying the wrapped score
     * @param wrap the number of times the player has wrapped
     * @return the string used by the UI for displaying the 
     *  score (number of times wrapped)
     * @pre wrap >= 0
     * @post none
     */
    // TODO Declare wrapString function

    /**
     * TODO Document updateLoc mutator
     */
    void updateLoc(int& loc, int move);

    /**
     * Update the number of wraps for a player at 
     * location loc moving move spaces
     * @param wrap reference to current wrap score
     * @param loc the currently location
     * @param move the number of spaces to move
     * @return none
     * @pre wrap>=0. 0<=loc<21
     * @post wrap will increase if the move causes the player 
     *   to wrap around the board.
     */
    // TODO Declaration of updateWrap mutator

    /**
     * Compute the next location given current location
     *  and move amount 
     * @param loc current location
     * @param move number of spaces to move
     * @return location after moving move spaces from loc
     * @pre 0 <= loc < 21. 
     * @post none
     */
    // TODO declare nextLoc function
    

    /**
     * TODO Document nextWrap function
     */ 
    int nextWrap(int wrap, int loc, int move);


  } //end model

  
  
} //end move


#endif
