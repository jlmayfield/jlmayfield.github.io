/*
  Logan Mayfield
*/


#include <iostream>
#include "move_lib.h"

int main( int argc, char* argv[] ){

  // Program State Variables
  int cur_loc{0}; // player location
  int num_wrap{0}; // number of times player wrapped

  while( true ){
    // write out game state
    movegame::ui::displayState(std::cout,cur_loc,num_wrap);		

    std::cout << '\n';
    
    // get the next move
    int move{0}; // user's move
    movegame::ui::getMoveWithPrompt(std::cout,std::cin,move);

    std::cout << '\n';
    
    // update the state
    movegame::model::updateState(cur_loc,num_wrap,move);		
  }

  return 0;
}
